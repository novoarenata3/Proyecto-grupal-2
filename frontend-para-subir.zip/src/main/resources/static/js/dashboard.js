// Pantalla 2: Dashboard. Usa GET /api/productos y GET /api/alertas.

requireLogin();
renderNav('dashboard');

async function cargar() {
  try {
    const [productos, alertas] = await Promise.all([
      api('/api/productos'),
      api('/api/alertas')
    ]);

    const activos = productos.filter((p) => p.activo !== false);
    document.getElementById('stat-activos').textContent = activos.length;
    document.getElementById('stat-alertas').textContent = alertas.length;
    document.getElementById('stat-ok').textContent = Math.max(activos.length - alertas.length, 0);

    const tbody = document.getElementById('tbody-alertas');
    if (!alertas.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="vacio">Todo en orden: no hay alertas 🎉</td></tr>';
      return;
    }
    tbody.innerHTML = alertas.map((a) => {
      const stock = pick(a, ['stockActual', 'stock']);
      const minimo = pick(a, ['stockMinimo', 'minimo']);
      const objetivo = pick(a, ['cantidadObjetivo', 'objetivo'], null);
      let sugerido = pick(a, ['sugerenciaCompra', 'cantidadSugerida', 'sugerencia', 'comprar'], null);
      if (sugerido === null && typeof objetivo === 'number' && typeof stock === 'number') {
        sugerido = objetivo - stock;
      }
      return `<tr>
        <td>${esc(pick(a, ['nombre', 'productoNombre', 'producto']))}</td>
        <td><span class="badge rojo">${esc(stock)}</span></td>
        <td>${esc(minimo)}</td>
        <td><strong>${esc(sugerido ?? '—')}</strong> ${esc(pick(a, ['unidad'], ''))}</td>
      </tr>`;
    }).join('');
  } catch (err) {
    toast(err.message, 'error');
  }
}

cargar();
