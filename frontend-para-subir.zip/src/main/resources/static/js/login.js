// Pantalla 1: Login. Valida las credenciales llamando a GET /api/me con HTTP Basic.

if (Auth.header()) location.href = 'dashboard.html';

document.getElementById('form-login').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const header = 'Basic ' + btoa(unescape(encodeURIComponent(`${username}:${password}`)));

  try {
    const me = await api('/api/me', { auth: header });
    Auth.save(header, me);
    location.href = 'dashboard.html';
  } catch (err) {
    toast(err.message, 'error');
  }
});
