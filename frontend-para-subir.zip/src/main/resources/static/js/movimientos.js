// Pantalla 4: Movimientos. Endpoints: POST /api/movimientos y POST /api/movimientos/ajustes (admin).

requireLogin();
renderNav('movimientos');

async function cargarProductos() {
  try {
    const productos = await api('/api/productos');
    llenarSelectProductos(document.getElementById('mov-producto'), productos);
    llenarSelectProductos(document.getElementById('aj-producto'), productos);
  } catch (err) {
    toast(err.message, 'error');
  }
}

document.getElementById('form-movimiento').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = {
    productoId: Number(document.getElementById('mov-producto').value),
    tipo: document.getElementById('mov-tipo').value,
    cantidad: Number(document.getElementById('mov-cantidad').value),
    motivo: document.getElementById('mov-motivo').value.trim()
  };
  try {
    await api('/api/movimientos', { method: 'POST', body });
    toast('Movimiento registrado');
    e.target.reset();
  } catch (err) {
    // Ej.: 409 si una salida deja el stock negativo o el producto está bloqueado
    toast(err.message, 'error');
  }
});

document.getElementById('form-ajuste').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = {
    productoId: Number(document.getElementById('aj-producto').value),
    nuevoStock: Number(document.getElementById('aj-stock').value),
    motivo: document.getElementById('aj-motivo').value.trim()
  };
  try {
    await api('/api/movimientos/ajustes', { method: 'POST', body });
    toast('Ajuste aplicado');
    e.target.reset();
  } catch (err) {
    toast(err.message, 'error');
  }
});

cargarProductos();
