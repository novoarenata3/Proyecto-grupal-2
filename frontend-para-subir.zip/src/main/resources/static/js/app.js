// Funciones compartidas por todas las pantallas de Smart Inventory.
// La API usa HTTP Basic: guardamos el encabezado en sessionStorage (se borra al cerrar la pestaña).

const Auth = {
  header: () => sessionStorage.getItem('authHeader'),
  user: () => {
    try { return JSON.parse(sessionStorage.getItem('me')); } catch { return null; }
  },
  save(header, me) {
    sessionStorage.setItem('authHeader', header);
    sessionStorage.setItem('me', JSON.stringify(me));
  },
  clear() { sessionStorage.clear(); }
};

// Llamada a la API. Lanza Error con el mensaje {"error": "..."} del backend.
async function api(path, { method = 'GET', body, auth } = {}) {
  const headers = {
    'Accept': 'application/json',
    // Evita que el navegador muestre su ventana emergente de login ante un 401
    'X-Requested-With': 'XMLHttpRequest'
  };
  const authHeader = auth || Auth.header();
  if (authHeader) headers['Authorization'] = authHeader;
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  const res = await fetch(path, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined
  });

  if (res.status === 401) {
    if (!auth) { Auth.clear(); location.href = 'index.html'; }
    throw new Error('Usuario o contraseña incorrectos');
  }

  let data = null;
  const text = await res.text();
  if (text) {
    try { data = JSON.parse(text); } catch { data = null; }
  }

  if (!res.ok) {
    const mensajes = {
      403: 'No tienes permiso para esta acción',
      404: 'No se encontró el recurso (¿el módulo ya está implementado?)',
      409: 'Conflicto con las reglas del inventario'
    };
    throw new Error((data && data.error) || mensajes[res.status] || `Error ${res.status}`);
  }
  return data;
}

// Escapa texto para insertarlo de forma segura en HTML
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));

// Devuelve el primer campo existente (los nombres exactos de la API pueden variar)
function pick(obj, keys, fallback = '—') {
  for (const k of keys) {
    if (obj && obj[k] !== undefined && obj[k] !== null) return obj[k];
  }
  return fallback;
}

function esAdmin() {
  return /ADMIN/i.test(JSON.stringify(Auth.user() || {}));
}

function requireLogin() {
  if (!Auth.header()) location.href = 'index.html';
  if (!esAdmin()) document.body.classList.add('no-admin');
}

function renderNav(activa) {
  const paginas = [
    ['dashboard', 'Dashboard', 'dashboard.html'],
    ['productos', 'Productos', 'productos.html'],
    ['movimientos', 'Movimientos', 'movimientos.html'],
    ['historial', 'Historial', 'historial.html']
  ];
  const me = Auth.user() || {};
  const nombre = pick(me, ['nombre', 'username'], 'Usuario');
  document.getElementById('nav').innerHTML = `
    <nav class="nav">
      <span class="brand">📦 Smart Inventory</span>
      ${paginas.map(([id, texto, href]) =>
        `<a href="${href}" class="${id === activa ? 'active' : ''}">${texto}</a>`).join('')}
      <span class="spacer"></span>
      <span class="user">${esc(nombre)}${esAdmin() ? ' (admin)' : ''}</span>
      <button id="btn-salir">Salir</button>
    </nav>`;
  document.getElementById('btn-salir').onclick = () => {
    Auth.clear();
    location.href = 'index.html';
  };
}

let toastTimer;
function toast(mensaje, tipo = 'ok') {
  const el = document.getElementById('toast');
  el.textContent = mensaje;
  el.className = `show ${tipo}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = ''; }, 3500);
}

// Llena un <select> con los productos (solo activos por defecto)
function llenarSelectProductos(select, productos, { conTodos = false } = {}) {
  const opciones = productos
    .filter((p) => p.activo !== false)
    .map((p) => `<option value="${esc(p.id)}">${esc(p.nombre)}</option>`);
  select.innerHTML = (conTodos ? '<option value="">Todos</option>' : '') + opciones.join('');
}

function formatearFecha(valor) {
  if (!valor) return '—';
  const d = new Date(valor);
  return isNaN(d) ? esc(valor) : d.toLocaleString('es-EC');
}
