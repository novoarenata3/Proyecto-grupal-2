// Pantalla 3: Productos. Endpoints: GET/POST/PUT/DELETE /api/productos y PATCH desactivar/reactivar.
// Crear, editar, desactivar, reactivar y eliminar son solo para administradores.

requireLogin();
renderNav('productos');

let productos = [];
const tbody = document.getElementById('tbody');
const form = document.getElementById('form-producto');

async function cargar() {
  try {
    productos = await api('/api/productos');
    render();
  } catch (err) {
    toast(err.message, 'error');
  }
}

function render() {
  if (!productos.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="vacio">Aún no hay productos</td></tr>';
    return;
  }
  tbody.innerHTML = productos.map((p) => {
    const activo = p.activo !== false;
    const stock = pick(p, ['stockActual', 'stock']);
    const bajo = typeof stock === 'number' && stock <= p.stockMinimo;
    const estado = !activo ? ['gris', 'Inactivo'] : bajo ? ['rojo', 'Stock bajo'] : ['verde', 'OK'];
    return `<tr class="${activo ? '' : 'inactivo'}">
      <td>${esc(p.nombre)}</td>
      <td>${esc(p.unidad)}</td>
      <td>${esc(stock)}</td>
      <td>${esc(p.stockMinimo)}</td>
      <td>${esc(p.cantidadObjetivo)}</td>
      <td><span class="badge ${estado[0]}">${estado[1]}</span></td>
      <td class="solo-admin acciones">
        <button class="btn small secondary" data-accion="editar" data-id="${esc(p.id)}">Editar</button>
        ${activo
          ? `<button class="btn small secondary" data-accion="desactivar" data-id="${esc(p.id)}">Desactivar</button>`
          : `<button class="btn small secondary" data-accion="reactivar" data-id="${esc(p.id)}">Reactivar</button>`}
        <button class="btn small danger" data-accion="eliminar" data-id="${esc(p.id)}">Eliminar</button>
      </td>
    </tr>`;
  }).join('');
}

function limpiarForm() {
  form.reset();
  document.getElementById('producto-id').value = '';
  document.getElementById('titulo-form').textContent = 'Nuevo producto';
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('producto-id').value;
  const body = {
    nombre: document.getElementById('nombre').value.trim(),
    unidad: document.getElementById('unidad').value.trim(),
    stockMinimo: Number(document.getElementById('stockMinimo').value),
    cantidadObjetivo: Number(document.getElementById('cantidadObjetivo').value)
  };
  if (body.cantidadObjetivo < body.stockMinimo) {
    toast('La cantidad objetivo no puede ser menor que el stock mínimo', 'error');
    return;
  }
  try {
    await api(id ? `/api/productos/${id}` : '/api/productos', { method: id ? 'PUT' : 'POST', body });
    toast(id ? 'Producto actualizado' : 'Producto creado');
    limpiarForm();
    cargar();
  } catch (err) {
    toast(err.message, 'error');
  }
});

document.getElementById('btn-cancelar').addEventListener('click', limpiarForm);

tbody.addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const { accion, id } = btn.dataset;

  if (accion === 'editar') {
    const p = productos.find((x) => String(x.id) === id);
    document.getElementById('producto-id').value = p.id;
    document.getElementById('nombre').value = p.nombre;
    document.getElementById('unidad').value = p.unidad;
    document.getElementById('stockMinimo').value = p.stockMinimo;
    document.getElementById('cantidadObjetivo').value = p.cantidadObjetivo;
    document.getElementById('titulo-form').textContent = 'Editar producto';
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }

  try {
    if (accion === 'desactivar') await api(`/api/productos/${id}/desactivar`, { method: 'PATCH' });
    if (accion === 'reactivar') await api(`/api/productos/${id}/reactivar`, { method: 'PATCH' });
    if (accion === 'eliminar') {
      if (!confirm('¿Eliminar este producto? Esta acción no se puede deshacer.')) return;
      await api(`/api/productos/${id}`, { method: 'DELETE' });
    }
    toast('Listo');
    cargar();
  } catch (err) {
    toast(err.message, 'error');
  }
});

cargar();
