// Pantalla 5: Historial. GET /api/movimientos con filtros opcionales productoId, desde, hasta (yyyy-MM-dd).

requireLogin();
renderNav('historial');

const tbody = document.getElementById('tbody');
const selProducto = document.getElementById('f-producto');

async function cargarProductos() {
  try {
    const productos = await api('/api/productos');
    // En el historial mostramos todos (también los inactivos) para poder consultarlos
    selProducto.innerHTML = '<option value="">Todos</option>' +
      productos.map((p) => `<option value="${esc(p.id)}">${esc(p.nombre)}</option>`).join('');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function cargarHistorial() {
  const params = new URLSearchParams();
  if (selProducto.value) params.set('productoId', selProducto.value);
  const desde = document.getElementById('f-desde').value;
  const hasta = document.getElementById('f-hasta').value;
  if (desde) params.set('desde', desde);
  if (hasta) params.set('hasta', hasta);

  if (desde && hasta && desde > hasta) {
    toast('La fecha "desde" no puede ser posterior a "hasta"', 'error');
    return;
  }

  try {
    const movimientos = await api('/api/movimientos' + (params.toString() ? `?${params}` : ''));
    if (!movimientos.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="vacio">No hay movimientos para estos filtros</td></tr>';
      return;
    }
    tbody.innerHTML = movimientos.map((m) => {
      const tipo = String(pick(m, ['tipo'], '')).toUpperCase();
      const clase = tipo === 'ENTRADA' ? 'verde' : tipo === 'SALIDA' ? 'rojo' : 'azul';
      return `<tr>
        <td>${formatearFecha(pick(m, ['fecha', 'fechaHora', 'creadoEn'], null))}</td>
        <td>${esc(pick(m, ['productoNombre', 'producto', 'nombreProducto']))}</td>
        <td><span class="badge ${clase}">${esc(tipo || '—')}</span></td>
        <td>${esc(pick(m, ['cantidad']))}</td>
        <td>${esc(pick(m, ['motivo']))}</td>
        <td>${esc(pick(m, ['usuario', 'username', 'empleado']))}</td>
      </tr>`;
    }).join('');
  } catch (err) {
    toast(err.message, 'error');
  }
}

document.getElementById('form-filtros').addEventListener('submit', (e) => {
  e.preventDefault();
  cargarHistorial();
});

document.getElementById('btn-limpiar').addEventListener('click', () => {
  document.getElementById('form-filtros').reset();
  cargarHistorial();
});

cargarProductos();
cargarHistorial();
